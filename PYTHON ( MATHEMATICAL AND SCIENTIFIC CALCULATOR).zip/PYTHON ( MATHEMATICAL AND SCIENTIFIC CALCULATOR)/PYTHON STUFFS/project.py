from tkinter import *


window=Tk()

L1= Label(window, text="Title")
L1.grid(row=0,column=0)

window.mainloop()   
 
