
from tkinter import *
emma=Tk()

emma.title("EMMANUEL")
emma.geometry("200x300")

emma.mainloop()
