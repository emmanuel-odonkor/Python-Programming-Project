import random

def NumberGuess1(a,b):
    if a==b:
        print("Correct!")

    elif b>a:
        print("Number entered was higher")
        b = eval(input("Try again: "))
        NumberGuess1(a,b)

    elif b<a:
        print("Number entered was lower")
        b = eval(input("Try again: "))
        NumberGuess1(a,b)


def NumberGuess():
    a = random.randint(0,100)
    b = eval(input("Guess the number: "))
    NumberGuess1(a,b)
    again = input("Would you like to go again? Enter a yes or no")
    if again=="y" or "Y":
        NumberGuess()

NumberGuess()







